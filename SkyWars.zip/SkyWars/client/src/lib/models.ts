import * as THREE from 'three';

export function loadModels(scene: THREE.Scene) {
  // Blue team jet
  const blueJet = createJet(0x0066CC);
  blueJet.scale.set(0.5, 0.5, 0.5);
  scene.add(blueJet);

  // Red team jet
  const redJet = createJet(0xCC0000);
  redJet.scale.set(0.5, 0.5, 0.5);
  scene.add(redJet);
}

function createJet(color: number): THREE.Group {
  const jet = new THREE.Group();

  // Fuselage
  const fuselage = new THREE.Mesh(
    new THREE.CylinderGeometry(0.5, 0.5, 4, 8),
    new THREE.MeshPhongMaterial({ color })
  );
  fuselage.rotation.z = Math.PI / 2;
  jet.add(fuselage);

  // Wings
  const wingGeometry = new THREE.BoxGeometry(3, 0.1, 1);
  const wingMaterial = new THREE.MeshPhongMaterial({ color });
  const wings = new THREE.Mesh(wingGeometry, wingMaterial);
  wings.position.set(0, 0, 0);
  jet.add(wings);

  // Tail
  const tailGeometry = new THREE.BoxGeometry(1, 0.1, 0.5);
  const tail = new THREE.Mesh(tailGeometry, wingMaterial);
  tail.position.set(-1.5, 0.5, 0);
  jet.add(tail);

  return jet;
}
