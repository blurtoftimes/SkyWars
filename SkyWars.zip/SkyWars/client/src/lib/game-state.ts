import * as THREE from 'three';
import { Player } from '@shared/schema';

const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
const wsUrl = `${protocol}//${window.location.host}/ws`;

let socket: WebSocket;
let players: Map<number, THREE.Object3D> = new Map();
let currentPlayerId: number;
let scene: THREE.Scene;
let camera: THREE.Camera;
let lastUpdate = Date.now();

interface KeyState {
  ArrowUp: boolean;
  ArrowDown: boolean;
  ArrowLeft: boolean;
  ArrowRight: boolean;
  Space: boolean;
}

const keyState: KeyState = {
  ArrowUp: false,
  ArrowDown: false,
  ArrowLeft: false,
  ArrowRight: false,
  Space: false
};

export function initGameState(_scene: THREE.Scene, _camera: THREE.Camera, playerId: number) {
  console.log('Initializing game state for player:', playerId);
  scene = _scene;
  camera = _camera;
  currentPlayerId = playerId;

  // Setup WebSocket
  socket = new WebSocket(wsUrl);

  socket.onmessage = (event: MessageEvent) => {
    try {
      const message = JSON.parse(event.data);
      console.log('Received message:', message);

      if (message.type === 'state') {
        updatePlayers(message.players as Player[]);
      }
    } catch (error) {
      console.error('Error processing message:', error);
    }
  };

  socket.onopen = () => {
    console.log('WebSocket connected');
  };

  socket.onerror = (error) => {
    console.error('WebSocket error:', error);
  };

  socket.onclose = () => {
    console.log('WebSocket connection closed');
  };

  // Setup controls
  window.addEventListener('keydown', handleKeyDown);
  window.addEventListener('keyup', handleKeyUp);

  return () => {
    window.removeEventListener('keydown', handleKeyDown);
    window.removeEventListener('keyup', handleKeyUp);
    socket.close();
  };
}

function handleKeyDown(event: KeyboardEvent) {
  if (event.code in keyState) {
    (keyState as any)[event.code] = true;
  }
}

function handleKeyUp(event: KeyboardEvent) {
  if (event.code in keyState) {
    (keyState as any)[event.code] = false;
  }
}

function updatePlayers(serverPlayers: Player[]) {
  console.log('Updating players:', serverPlayers);

  // Remove players that are no longer in the game
  for (const [id, obj] of players.entries()) {
    if (!serverPlayers.find(p => p.id === id)) {
      scene.remove(obj);
      players.delete(id);
    }
  }

  // Update or create players
  serverPlayers.forEach((serverPlayer) => {
    let playerObject = players.get(serverPlayer.id);
    if (!playerObject) {
      console.log('Creating new player object for:', serverPlayer.id);
      playerObject = createJetModel(serverPlayer.team === 'blue' ? 0x0066CC : 0xCC0000);
      scene.add(playerObject);
      players.set(serverPlayer.id, playerObject);
    }

    playerObject.position.set(serverPlayer.x, serverPlayer.y, serverPlayer.z);
    playerObject.rotation.y = serverPlayer.rotation;

    // Make non-alive players semi-transparent
    const materials = playerObject.children.map(child => 
      (child as THREE.Mesh).material as THREE.MeshPhongMaterial
    ).flat();

    materials.forEach(material => {
      material.transparent = !serverPlayer.isAlive;
      material.opacity = serverPlayer.isAlive ? 1.0 : 0.5;
    });
  });
}

function createJetModel(color: number): THREE.Group {
  const jet = new THREE.Group();

  // Fuselage
  const fuselage = new THREE.Mesh(
    new THREE.CylinderGeometry(0.5, 0.5, 4, 8),
    new THREE.MeshPhongMaterial({ color })
  );
  fuselage.rotation.z = Math.PI / 2;
  jet.add(fuselage);

  // Wings
  const wingGeometry = new THREE.BoxGeometry(3, 0.1, 1);
  const wingMaterial = new THREE.MeshPhongMaterial({ color });
  const wings = new THREE.Mesh(wingGeometry, wingMaterial);
  wings.position.set(0, 0, 0);
  jet.add(wings);

  // Tail
  const tailGeometry = new THREE.BoxGeometry(1, 0.1, 0.5);
  const tail = new THREE.Mesh(tailGeometry, wingMaterial);
  tail.position.set(-1.5, 0.5, 0);
  jet.add(tail);

  return jet;
}

export function updateGameState() {
  const now = Date.now();
  const delta = (now - lastUpdate) / 1000;
  lastUpdate = now;

  // Update player position based on input
  const currentPlayer = players.get(currentPlayerId);
  if (currentPlayer) {
    let changed = false;
    const moveSpeed = 10;
    const rotateSpeed = 2;

    if (keyState.ArrowUp) {
      currentPlayer.position.z -= moveSpeed * delta;
      changed = true;
    }
    if (keyState.ArrowDown) {
      currentPlayer.position.z += moveSpeed * delta;
      changed = true;
    }
    if (keyState.ArrowLeft) {
      currentPlayer.rotation.y += rotateSpeed * delta;
      changed = true;
    }
    if (keyState.ArrowRight) {
      currentPlayer.rotation.y -= rotateSpeed * delta;
      changed = true;
    }

    // Send position update
    if (changed && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: 'position',
        id: currentPlayerId,
        x: currentPlayer.position.x,
        y: currentPlayer.position.y,
        z: currentPlayer.position.z,
        rotation: currentPlayer.rotation.y
      }));
    }

    // Update camera position
    const cameraOffset = new THREE.Vector3(0, 5, 10);
    cameraOffset.applyQuaternion(currentPlayer.quaternion);
    camera.position.copy(currentPlayer.position).add(cameraOffset);
    camera.lookAt(currentPlayer.position);
  }
}