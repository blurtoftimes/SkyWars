import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { Player } from "@shared/schema";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface TeamSelectProps {
  onSelect: (player: Player) => void;
}

export default function TeamSelect({ onSelect }: TeamSelectProps) {
  const [username, setUsername] = useState("");
  const { toast } = useToast();

  const selectTeam = async (team: string) => {
    try {
      const res = await apiRequest("POST", "/api/players", { username, team });
      const player = await res.json();
      onSelect(player);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to join team",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <Card className="w-[400px]">
        <CardContent className="pt-6">
          <h1 className="text-2xl font-bold mb-4 text-center">Join the Battle</h1>
          <input
            type="text"
            placeholder="Enter username"
            className="w-full p-2 mb-4 rounded bg-card border border-border"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <div className="flex gap-4">
            <Button
              className="w-full bg-[#0066CC] hover:bg-[#0055AA]"
              onClick={() => selectTeam("blue")}
              disabled={!username}
            >
              Blue Team
            </Button>
            <Button
              className="w-full bg-[#CC0000] hover:bg-[#AA0000]"
              onClick={() => selectTeam("red")}
              disabled={!username}
            >
              Red Team
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
