import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { initGameState, updateGameState } from '@/lib/game-state';
import { loadModels } from '@/lib/models';

interface SceneProps {
  playerId: number;
}

export default function Scene({ playerId }: SceneProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    console.log('Initializing 3D scene for player:', playerId);

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#87CEEB');

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.set(0, 5, 10);

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
    });
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);
    containerRef.current.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(1, 1, 1);
    scene.add(directionalLight);

    // Ground plane for reference
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(1000, 1000),
      new THREE.MeshPhongMaterial({ color: 0x1a472a })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -50;
    scene.add(ground);

    console.log('Scene setup complete, initializing game state');

    // Initialize game state
    const cleanup = initGameState(scene, camera, playerId);

    // Load models
    loadModels(scene);

    // Animation loop
    function animate() {
      requestAnimationFrame(animate);
      updateGameState();
      renderer.render(scene, camera);
    }
    animate();

    // Handle resize
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cleanup();
      window.removeEventListener('resize', handleResize);
      if (containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, [playerId]);

  return <div ref={containerRef} className="w-full h-full" />;
}