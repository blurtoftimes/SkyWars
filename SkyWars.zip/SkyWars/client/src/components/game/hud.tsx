import { Player } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

interface HUDProps {
  player: Player;
}

export default function HUD({ player }: HUDProps) {
  const { data: players = [] } = useQuery<Player[]>({
    queryKey: ['/api/players'],
    refetchInterval: 1000
  });

  const blueScore = players.reduce((acc, p) => 
    p.team === 'blue' ? acc + p.score : acc, 0);
  const redScore = players.reduce((acc, p) => 
    p.team === 'red' ? acc + p.score : acc, 0);

  return (
    <div className="absolute inset-0 pointer-events-none p-4 font-[Rajdhani]">
      {/* Score Display */}
      <div className="flex justify-between text-2xl font-bold">
        <div className="text-[#0066CC]">Blue: {blueScore}</div>
        <div className="text-[#CC0000]">Red: {redScore}</div>
      </div>

      {/* Player Status */}
      <div className="absolute bottom-4 left-4 text-white">
        <div>Score: {player.score}</div>
        <div className={player.isAlive ? "text-[#FFD700]" : "text-[#CC0000]"}>
          Status: {player.isAlive ? "Active" : "Respawning..."}
        </div>
      </div>

      {/* Targeting Reticle */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        <svg width="64" height="64" viewBox="0 0 64 64">
          <circle cx="32" cy="32" r="30" 
            stroke={player.team === 'blue' ? '#0066CC' : '#CC0000'} 
            strokeWidth="2" 
            fill="none" 
          />
          <line x1="32" y1="16" x2="32" y2="48" 
            stroke={player.team === 'blue' ? '#0066CC' : '#CC0000'} 
            strokeWidth="2" 
          />
          <line x1="16" y1="32" x2="48" y2="32" 
            stroke={player.team === 'blue' ? '#0066CC' : '#CC0000'} 
            strokeWidth="2" 
          />
        </svg>
      </div>
    </div>
  );
}