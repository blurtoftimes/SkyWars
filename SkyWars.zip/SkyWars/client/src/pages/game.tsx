import { useState } from 'react';
import TeamSelect from '@/components/game/team-select';
import Scene from '@/components/game/scene';
import HUD from '@/components/game/hud';
import { Player } from '@shared/schema';

export default function Game() {
  const [player, setPlayer] = useState<Player | null>(null);

  if (!player) {
    return <TeamSelect onSelect={setPlayer} />;
  }

  return (
    <div className="relative w-screen h-screen">
      <Scene playerId={player.id} />
      <HUD player={player} />
    </div>
  );
}
