import { players, type Player, type InsertPlayer } from "@shared/schema";

export interface IStorage {
  createPlayer(player: InsertPlayer): Promise<Player>;
  getPlayer(id: number): Promise<Player | undefined>;
  updatePlayerPosition(id: number, x: number, y: number, z: number, rotation: number): Promise<void>;
  updatePlayerScore(id: number, score: number): Promise<void>;
  updatePlayerStatus(id: number, isAlive: boolean): Promise<void>;
  getAllPlayers(): Promise<Player[]>;
}

export class MemStorage implements IStorage {
  private players: Map<number, Player>;
  private currentId: number;

  constructor() {
    this.players = new Map();
    this.currentId = 1;
  }

  async createPlayer(insertPlayer: InsertPlayer): Promise<Player> {
    const id = this.currentId++;
    const player: Player = {
      id,
      score: 0,
      isAlive: true,
      x: 0,
      y: 100,
      z: 0,
      rotation: 0,
      ...insertPlayer
    };
    this.players.set(id, player);
    return player;
  }

  async getPlayer(id: number): Promise<Player | undefined> {
    return this.players.get(id);
  }

  async updatePlayerPosition(id: number, x: number, y: number, z: number, rotation: number): Promise<void> {
    const player = this.players.get(id);
    if (player) {
      player.x = x;
      player.y = y;
      player.z = z;
      player.rotation = rotation;
    }
  }

  async updatePlayerScore(id: number, score: number): Promise<void> {
    const player = this.players.get(id);
    if (player) {
      player.score = score;
    }
  }

  async updatePlayerStatus(id: number, isAlive: boolean): Promise<void> {
    const player = this.players.get(id);
    if (player) {
      player.isAlive = isAlive;
    }
  }

  async getAllPlayers(): Promise<Player[]> {
    return Array.from(this.players.values());
  }
}

export const storage = new MemStorage();
