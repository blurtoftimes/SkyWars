import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocket, WebSocketServer } from "ws";
import { storage } from "./storage";
import { insertPlayerSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  app.post("/api/players", async (req, res) => {
    const result = insertPlayerSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: "Invalid player data" });
    }

    const player = await storage.createPlayer(result.data);
    res.json(player);
  });

  app.get("/api/players", async (_req, res) => {
    const players = await storage.getAllPlayers();
    res.json(players);
  });

  wss.on('connection', (ws) => {
    console.log('New WebSocket connection established');

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        console.log('Received message:', message);

        switch (message.type) {
          case 'position':
            await storage.updatePlayerPosition(
              message.id,
              message.x,
              message.y,
              message.z,
              message.rotation
            );
            break;
          case 'hit':
            await storage.updatePlayerStatus(message.targetId, false);
            await storage.updatePlayerScore(message.sourceId, message.score);
            setTimeout(async () => {
              await storage.updatePlayerStatus(message.targetId, true);
            }, 3000);
            break;
        }

        // Broadcast updated state to all clients
        const players = await storage.getAllPlayers();
        wss.clients.forEach((client) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ type: 'state', players }));
          }
        });
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    // Send initial state to the new client
    storage.getAllPlayers().then(players => {
      ws.send(JSON.stringify({ type: 'state', players }));
    });
  });

  return httpServer;
}