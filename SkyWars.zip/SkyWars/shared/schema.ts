import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  username: text("username").notNull(),
  team: text("team").notNull(),
  score: integer("score").notNull().default(0),
  isAlive: boolean("is_alive").notNull().default(true),
  x: integer("x").notNull().default(0),
  y: integer("y").notNull().default(0),
  z: integer("z").notNull().default(0),
  rotation: integer("rotation").notNull().default(0)
});

export const insertPlayerSchema = createInsertSchema(players).pick({
  username: true,
  team: true
});

export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type Player = typeof players.$inferSelect;
